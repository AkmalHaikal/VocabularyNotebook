from flask import (Flask,
                   request,
                   render_template,
                   redirect, url_for,
                   jsonify)

from pymongo import MongoClient
import requests

app = Flask(__name__)

password = 'akmal392'
cxn_str = 'mongodb+srv://AkmDB:{password}@cluster0.knrmbyg.mongodb.net/?retryWrites=true&w=majority'
client = MongoClient(cxn_str)

db = client.dbsparta_plus_week2


@app.route('/')
def main():
    return render_template('index.html')


@app.route('/detail/<keyword>')
def detail(keyword):
    print(keyword)
    return render_template('detail.html', word=keyword)


@app.route('/api/save_word', methods=['POST'])
def save_word():
    return jsonify({
        'result': ' success',
        'msg': 'the word was saved',
    })


@app.route('/api/delete_word', methods=['POST'])
def delete_word():
    return jsonify({
        'result': 'success',
        'msg': 'the word was delete',
    })


if __name__ == '__main__':
    app.run('0.0.0.0', port=5000, debug=True)
